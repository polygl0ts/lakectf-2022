require "test_helper"

class CalcJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
